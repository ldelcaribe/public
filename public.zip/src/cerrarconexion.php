<?php
$conexion->close();
?>